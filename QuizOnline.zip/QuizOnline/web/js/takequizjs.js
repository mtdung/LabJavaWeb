var index = 0;
var txt = '';
var totaltime;
function setValue(time) {
    totaltime = time;
}
var questions = document.getElementsByClassName("exam");
//display question first when start
function display() {
    //Hide all question 
    for (var i = 0; i < questions.length; i++) {
        questions[i].style.display = 'none';
    }
    questions[index].style.display = 'block';
}
//submit server if click next quiz at last question 
function finishTest() {
    //if this question is the last question then create submit form to submit server
    if (index == questions.length - 1) {
        var form = document.createElement("form");
        form.method = "GET";
        form.action = "result";
        form.style.display = "none";

        var input = document.createElement("input");
        input.type = "text";
        input.name = "answerResult";
        input.value = txt;
        form.appendChild(input);
        document.body.appendChild(form);
        form.submit();
    }
}
//display question when click next question and save answer  
function nextQuiz(qid) {
    txt += qid + "-"; // 3-
    var choose = document.querySelectorAll("input[type=checkbox]:checked");
    //check if user not choose any answer
    if (choose.length != 0) {
        for (var i = 0; i < choose.length; i++) {
            //check add " " for the answer excepted the last answer
            if (i != choose.length - 1) {
                txt += choose[i].value + " "; //3-1 4
            } else {
                txt += choose[i].value;
            }
        }
        //after add answer checked in txt then unchecked all answer
        for (var i = 0; i < choose.length; i++) {
            choose[i].checked = false;
        }
    }
    //check if this question isn't the last question then add "|"
    if (index != questions.length - 1) {
        txt += "|";
    }
    finishTest();
    //console.log(txt);
    index++;
    //Hode all question
    display();
}
//display time and make time descrese one per second 
function time() {
    totaltime--;
    var minute = /*Math.floor(totaltime / 60)*/5;
    var second = /*totaltime - minute * 60*/50;
    var timeDisplay = document.getElementById("time");
    if (second < 10) {
        timeDisplay.innerHTML = "0" + minute + ":" + "0" + second;
    } else {
        timeDisplay.innerHTML = "0" + minute + ":" + second;
    }
    //if times up then auto submit server
    if (totaltime == 0) {
        document.getElementsByTagName('button')[index].click();
        //document.getElementById("btnNext").click();
    }
}



