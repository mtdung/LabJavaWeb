/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DBContext.DBContext;
import entity.Question;
import entity.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Funny
 */
public class quizDAO {

    public User getUser(String username, String pass) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String querry = "select * from [User]\n"
                + "where username = ? and password = ?";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, username);
            ps.setString(2, pass);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new User(rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getInt("role"),
                        rs.getString("email"));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return null;
    }

    public void createAccount(String username, String pass, int role, String email) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String querry = "INSERT INTO [dbo].[User]\n"
                + "           ([username]\n"
                + "           ,[password]\n"
                + "           ,[role]\n"
                + "           ,[email])\n"
                + "     VALUES\n"
                + "           (?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?)";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, username);
            ps.setString(2, pass);
            ps.setInt(3, role);
            ps.setString(4, email);
            ps.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
    }

    public boolean checkAccount(String username) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String querry = "select * from [User] \n"
                + "where username = ?";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, username);
            rs = ps.executeQuery();
            while (rs.next()) {
                return true;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return false;
    }

    public void makeQuiz(String question, String option1, String option2, String option3,
            String option4, String answer, String date, int userID) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String querry = "INSERT INTO [dbo].[Quiz]\n"
                + "           ([question]\n"
                + "           ,[option1]\n"
                + "           ,[option2]\n"
                + "           ,[option3]\n"
                + "           ,[option4]\n"
                + "           ,[answer]\n"
                + "           ,[date]\n"
                + "           ,[user_id])\n"
                + "     VALUES\n"
                + "           (?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?)";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(querry);
            ps.setString(1, question);
            ps.setString(2, option1);
            ps.setString(3, option2);
            ps.setString(4, option3);
            ps.setString(5, option4);
            ps.setString(6, answer);
            ps.setString(7, date);
            ps.setInt(8, userID);
            ps.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
    }

    public List<Question> getQuestionbyUserID(int userID) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String querry = "select * from Quiz \n"
                + "where user_id = ?";
        List<Question> list = new ArrayList<>();
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(querry);
            ps.setInt(1, userID);
            rs = ps.executeQuery();
            while (rs.next()) {
                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                list.add(new Question(rs.getInt("id"),
                        rs.getString("question"), rs.getString("option1"),
                        rs.getString("option2"), rs.getString("option3"),
                        rs.getString("option4"), rs.getString("answer"),
                        df.format(rs.getDate("date")), rs.getInt("user_id")));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return list;
    }
    
    public void deleteQuestion(int id) throws Exception{
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String querry = "DELETE FROM [dbo].[Quiz] WHERE id = ?";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(querry);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
    }

    public List<Question> getListQuiz(int number) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String querry = "select top (?) * from Quiz \n"
                + "order by newID()";
        List<Question> list = new ArrayList<>();
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(querry);
            ps.setInt(1, number);
            rs = ps.executeQuery();
            while(rs.next()){
                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                list.add(new Question(rs.getInt("id"),
                        rs.getString("question"), rs.getString("option1"),
                        rs.getString("option2"), rs.getString("option3"),
                        rs.getString("option4"), rs.getString("answer"),
                        df.format(rs.getDate("date")), rs.getInt("user_id")));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return list;
    }
}
