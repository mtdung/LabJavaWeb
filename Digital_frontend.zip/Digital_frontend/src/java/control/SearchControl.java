/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import DAO.DigitalDAO;
import context.DBContext;
import entity.Digital;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Funny
 */
public class SearchControl extends RightControl {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("text/html;charset=UTF-8");
            String txt = request.getParameter("txtSearch");
            String indexString = request.getParameter("index");
            int index = 0;
            int check = 0;
            try {
                index = Integer.parseInt(indexString); 
                check = 1;
            } catch (Exception e) {
                request.setAttribute("error", "Page invalid");
            }
            // if index invalid then get data to jsp 
            if(check == 1){
                int count = dao.countSearch(txt);
                int size = 3;
                int lastPage = count / size;
                //if total number news search indivisible size then last page add one more 
                if (count % size != 0) {
                    lastPage++;
                }
                List<Digital> listS = dao.searchNews(txt, index, size);
                request.setAttribute("listS", listS);
                request.setAttribute("lastPage", lastPage);
                request.setAttribute("txt", txt);
                request.setAttribute("index", index);
                request.setAttribute("txtS", txt);
            }
            
            request.getRequestDispatcher("SearchPage.jsp").forward(request, response);
        } catch (Exception ex) {
            request.setAttribute("error", "System Error!");
            request.getRequestDispatcher("Error.jsp").forward(request, response);
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void processGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void processPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String txt = request.getParameter("txtSearch");
        response.sendRedirect("search?index=1&txtSearch="+txt);
    }

}
