/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import context.DBContext;
import entity.Digital;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Funny
 */
public class DigitalDAO {

    public Digital getTop1() throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "select top 1 * from digital\n"
                + "order by timePost desc";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                SimpleDateFormat dateF = new SimpleDateFormat("MMM dd yyyy - h:mm");
                SimpleDateFormat dateF2 = new SimpleDateFormat("a");
                String dateFormat = dateF.format(rs.getTimestamp("timePost")) 
                        + dateF2.format(rs.getTimestamp("timePost")).toLowerCase();
                return new Digital(rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("image"),
                        rs.getString("author"),
                        dateFormat,
                        rs.getString("shortDescription"));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return null;
    }

    public List<Digital> getTop5() throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Digital> list = new ArrayList<>();
        String query = "select top 5.* from digital\n"
                + "where id not in (select top 1.id from digital "
                + "order by timePost desc)\n"
                + "order by timePost desc";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                SimpleDateFormat dateF = new SimpleDateFormat("MMM dd yyyy - h:mm");
                SimpleDateFormat dateF2 = new SimpleDateFormat("a");
                String dateFormat = dateF.format(rs.getTimestamp("timePost")) 
                        + dateF2.format(rs.getTimestamp("timePost")).toLowerCase();
                list.add(new Digital(rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("image"),
                        rs.getString("author"),
                        dateFormat,
                        rs.getString("shortDescription")));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return list;
    }

    public Digital getNewsByID(String id) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "select * from digital \n"
                + "where id = ?";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                SimpleDateFormat dateF = new SimpleDateFormat("MMM dd yyyy - h:mm");
                SimpleDateFormat dateF2 = new SimpleDateFormat("a");
                String dateFormat = dateF.format(rs.getTimestamp("timePost")) 
                        + dateF2.format(rs.getTimestamp("timePost")).toLowerCase();
                return new Digital(rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("image"),
                        rs.getString("author"),
                        dateFormat,
                        rs.getString("shortDescription"));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return null;
    }

    public int countSearch(String txt) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        String query = "select count(*) from digital \n"
                + "where title like ?";
        try {
            
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txt + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
            return count;
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
    }

    public List<Digital> searchNews(String txt, int index, int size) throws Exception  {
        
            DBContext db = new DBContext();
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            List<Digital> list = new ArrayList();
            String query = "select * from digital \n"
                    + "where title like '%'+?+'%'\n"
                    + "ORDER BY id OFFSET ? ROWS\n"
                    + "FETCH NEXT ? ROWS ONLY";
        try{
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1,txt);
            ps.setInt(2, (index-1)*size);
            ps.setInt(3, size);
            rs = ps.executeQuery();
            while (rs.next()) {
                SimpleDateFormat dateF = new SimpleDateFormat("MMM dd yyyy - h:mm");
                SimpleDateFormat dateF2 = new SimpleDateFormat("a");
                String dateFormat = dateF.format(rs.getTimestamp("timePost")) 
                        + dateF2.format(rs.getTimestamp("timePost")).toLowerCase();
                list.add(new Digital(rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("image"),
                        rs.getString("author"),
                        dateFormat,
                        rs.getString("shortDescription")));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(rs, ps, conn);
        }
        return list;
    }           
}
