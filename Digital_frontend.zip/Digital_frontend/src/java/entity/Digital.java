/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import context.DBContext;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Funny
 */
public class Digital {
    private int id;
    private String title;
    private String description;
    private String image;
    private String author;
    private String time;
    private String shortdes;

    public Digital() {
    }

    public Digital(int id, String title, String description, String image, String author, String time, String shortdes) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.image = image;
        this.author = author;
        this.time = time;
        this.shortdes = shortdes;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getShortdes() {
        return shortdes;
    }

    public void setShortdes(String shortdes) {
        this.shortdes = shortdes;
    }

    @Override
    public String toString() {
        return "Digital{" + "id=" + id + ", title=" + title + ", description=" + description + ", image=" + image + ", author=" + author + ", time=" + time + ", shortdes=" + shortdes + '}';
    }
    
}
