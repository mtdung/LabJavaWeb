/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Funny
 */
public class DigitalDAOTest {
    
    public DigitalDAOTest() {       
    }

    @Test
    public void testGetTop1() throws Exception {
        
    }

    @Test
    public void testGetTop5() throws Exception {
    }

    @Test
    public void testGetNewsByID() throws Exception {
    }

    @Test
    public void testCountSearch() throws Exception {
    }

    @Test
    public void testSearchNews() throws Exception {
    }
    
}
